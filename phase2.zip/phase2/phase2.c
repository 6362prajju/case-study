// Define a structure for user data
struct User {
    char user_name[20];
    int user_id;
    long long int phone_no;
};

// Function prototypes
void new_user();



// Function to get user data
void new_user(struct User* user) {
    printf("\n\nEnter the new username : ");
    scanf("%s", user->user_name);
    printf("\nEnter the new user id : ");
    scanf("%d", &user->user_id);
    printf("\nEnter your phone number : ");
    scanf("%lld", &user->phone_no);

    printf("\n\n                ******** AVAILABLE ITEMS IN THE STORE ********\n\n");

    char items[][100] = {"Apple", "Mango", "Books", "Pen", "Cookies", "Powder", "Haldirams_special", "Ice-Cream", "Coconut", "Chocolates"};

    for (int i = 0; i < 10; i++) {
        printf("%d. %s\n", i + 1, items[i]);
    }

    int num_items;
    printf("\nEnter the number of items you want to shop : ");
    scanf("%d", &num_items);

    int total = 0;
    for (int j = 0; j < num_items; j++) {
        int choice;
        printf("\n\nChoose the item you want to buy : ");
        scanf("%d", &choice);

        int qty, price;
        printf("\nEnter the quantity : ");
        scanf("%d", &qty);

        switch (choice) {
            case 1: price = qty * 15; break;
            case 2: price = qty * 20; break;
            case 3: price = qty * 40; break;
            case 4: price = qty * 10; break;
            case 5: price = qty * 30; break;
            case 6: price = qty * 25; break;
            case 7: price = qty * 50; break;
            case 8: price = qty * 35; break;
            case 9: price = qty * 25; break;
            case 10: price = qty * 5; break;
            default: printf("Invalid choice!"); continue;
        }

        total += price;
    }

    printf("\n\nYour total amount is : %d/-", total);
    printf("\n\n\n            ******** THANK YOU FOR SHOPPING, VISIT AGAIN *********");
}



