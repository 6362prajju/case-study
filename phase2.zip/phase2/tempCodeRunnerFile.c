#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a struct to represent an item in the store
typedef struct {
    char name[100];
    int price;
} Item;

void new_user(Item *items, int num_items) {
    char user_name[10];
    int user_id;
    long long int phone_no;
    printf("\n\nEnter the new username : ");
    scanf("%s", user_name);
    printf("\nEnter the new user id : ");
    scanf("%d", &user_id);
    printf("\nEnter your phone number : ");
    scanf("%lld", &phone_no);
    printf("\n\n                ******** AVAILABLE ITEMS IN THE STORE ********\n\n");
    for (int i = 0; i < num_items; i++) {
        printf("%d. %s\n", i + 1, items[i].name);
    }

    int items_to_buy;
    printf("\nEnter the number of items you want to shop : ");
    scanf("%d", &items_to_buy);
    int total = 0;
    for (int j = 0; j < items_to_buy; j++) {
        int choice;
        printf("\n\nChoose the item you want to buy : ");
        scanf("%d", &choice);
        int qty = 0;
        printf("\nEnter the quantity : ");
        scanf("%d", &qty);
        if (choice >= 1 && choice <= num_items) {
            total += qty * items[choice - 1].price;
        } else {
            printf("Invalid choice!\n");
            j--; // decrement j to re-ask for the invalid choice
        }
    }
    printf("\n\nYour total amount is : %d/-", total);
    printf("\n\n\n            ******** THANK YOU FOR SHOPPING, VISIT AGAIN *********");
}

int main() {
    printf("                      --:WELCOME TO THE SHOPPING MART:--");

    // Dynamically allocate memory for the items array
    int num_items = 10; // number of items in the store
    Item *items = (Item *)malloc(num_items * sizeof(Item));
    if (items == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    // Initialize items
    strcpy(items[0].name, "Apple");
    items[0].price = 15;
    strcpy(items[1].name, "Mango");
    items[1].price = 20;
    // Similarly initialize other items...

    new_user(items, num_items);

    // Free dynamically allocated memory
    free(items);

    return 0;
}
