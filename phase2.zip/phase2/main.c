#include <stdio.h>
#include <stdlib.h>
#include "phase2.c"


int main() {
    printf("                      --:WELCOME TO THE SHOPPING MART:--");

    // Allocate memory for user structure
    struct User* user = (struct User*)malloc(sizeof(struct User));
    if (user == NULL) {
        printf("Memory allocation failed");
        return 1;
    }

    // Call function to get user data
    new_user(user);

    // Free allocated memory
    free(user);

    return 0;
}
