#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct User {
    char user_name[20];
    int user_id;
    long long int phone_no;
};

void new_user(struct User* user);
void save_user_to_file(struct User* user, const char* filename, const char* items[], int total);
void search_user_in_file(const char* filename);
void shop_items(struct User* user, const char* filename);

void new_user(struct User* user) {
    const char* filename = "filename.txt";

    printf("\nEnter the new username: ");
    scanf("%s", user->user_name);
    printf("Enter the new user id: ");
    scanf("%d", &user->user_id);
    printf("Enter your phone number: ");
    scanf("%lld", &user->phone_no);

    shop_items(user, filename);
}

void save_user_to_file(struct User* user, const char* filename, const char* items[], int total) {
    FILE* file = fopen(filename, "a");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }
    fprintf(file, "Username: %s, User ID: %d, Phone Number: %lld\n", user->user_name, user->user_id, user->phone_no);
    fprintf(file, "Purchased Items:\n");
    for (int i = 0; i < 10; i++) {
        if (items[i] != NULL) {
            fprintf(file, "  %s\n", items[i]);
        }
    }
    fprintf(file, "Total: %d\n", total);
    fprintf(file, "----------------------\n");
    fclose(file);
}

void search_user_in_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return;
    }

    char line[256];
    int user_id;
    printf("\nEnter the user ID to search: ");
    scanf("%d", &user_id);

    int found = 0;
    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, "User ID:") && atoi(strchr(line, ':') + 1) == user_id) {
            found = 1;
            printf("%s", line);
            while (fgets(line, sizeof(line), file) && line[0] != '-') {
                printf("%s", line);
            }
            break;
        }
    }

    if (!found) {
        printf("User with ID %d not found.\n", user_id);
    }

    fclose(file);
}

void shop_items(struct User* user, const char* filename) {
    printf("\n\n                ******** AVAILABLE ITEMS IN THE STORE ********\n\n");

    char items[][100] = {
        "Apple", "Mango", "Books", "Pen", "Cookies",
        "Powder", "Haldirams_special", "Ice-Cream", "Coconut", "Chocolates"
    };
    int prices[] = {15, 20, 40, 10, 30, 25, 50, 35, 25, 5};

    for (int i = 0; i < 10; i++) {
        printf("%d. %s - Rs.%d\n", i + 1, items[i], prices[i]);
    }

    int num_items;
    printf("\nEnter the number of different items you want to shop: ");
    scanf("%d", &num_items);

    int total = 0;
    const char* purchased_items[10] = {NULL};
    int count = 0;

    for (int j = 0; j < num_items; j++) {
        int choice, qty;
        printf("\n\nChoose the item you want to buy (number): ");
        scanf("%d", &choice);
        if (choice < 1 || choice > 10) {
            printf("Invalid choice! Please choose a valid item number.\n");
            j--; // Invalid choice, retry this iteration
            continue;
        }
        printf("Enter the quantity: ");
        scanf("%d", &qty);

        purchased_items[count++] = items[choice - 1];
        total += prices[choice - 1] * qty;
    }

    printf("\n\nYour total amount is: Rs.%d\n", total);
    printf("\n\n\n            ******** THANK YOU FOR SHOPPING, VISIT AGAIN *********\n");

    save_user_to_file(user, filename, purchased_items, total);
}








