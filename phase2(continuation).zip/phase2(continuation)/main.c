#include <stdio.h>
#include <stdlib.h>
#include "phase2continuation.c"


int main() {
    printf("                      --:WELCOME TO THE SHOPPING MART:--\n");

    struct User* user = (struct User*)malloc(sizeof(struct User));
    if (user == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    new_user(user);
    free(user);

    char option;
    printf("\nDo you want to search for a user (y/n)? ");
    scanf(" %c", &option);
    if (option == 'y' || option == 'Y') {
        search_user_in_file("filename.txt");
    }

    return 0;
}

